
public class Keyboard {

	public void info() {
		System.out.println("삼성키보드");
	}
}
