
public class Mouse {

	public void info() {
		System.out.println("LG마우스");
	}
}
