public class Monitor {

	public void info() {
		System.out.println("apple모니터");
	}
}
